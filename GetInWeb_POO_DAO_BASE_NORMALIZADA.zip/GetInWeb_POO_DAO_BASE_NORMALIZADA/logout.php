<?php
// VERSIÓN COMENTADA PARA ESTUDIO.

/*
    Cierre de sesión.
    No muestra una pantalla: destruye la sesión y vuelve al inicio.
*/

require_once "conexion.php";

use App\Servicios\ServicioAutenticacion;

// Cierra la sesión y vuelve al inicio.
ServicioAutenticacion::cerrarSesion();

header('Location: index.php');
exit();
