<?php
// VERSIÓN COMENTADA PARA ESTUDIO.

/*
    Preparador de base de datos.

    Este archivo prepara la estructura mínima del sistema.
    Si una tabla no existe, la crea.
    Si falta alguna columna importante, intenta agregarla.
    También agrega índices y claves foráneas para que la base quede mejor relacionada.
*/

namespace App\Servicios;

use mysqli;

class PreparadorBaseDatos
{
    private static bool $done = false;

    /**
     * Ejecuta una consulta sin cortar el sistema si la consulta no se puede aplicar.
     *
     * Esto sirve para ALTER TABLE repetidos. Por ejemplo, si una columna ya existe,
     * MySQL da error, pero no necesitamos detener toda la página.
     */
    private static function safe(mysqli $conexion, string $sql): void
    {
        try {
            $conexion->query($sql);
        } catch (\Throwable $e) {
            // No se corta la ejecución porque puede tratarse de una columna,
            // índice o clave foránea que ya existe.
        }
    }

    /**
     * Prepara todas las tablas necesarias.
     */
    public static function preparar(mysqli $conexion): void
    {
        if (self::$done) {
            return;
        }

        self::$done = true;

        // =========================================================
        // 1. Tabla usuarios
        // =========================================================

        self::safe($conexion, "CREATE TABLE IF NOT EXISTS usuarios (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nombre VARCHAR(100) NOT NULL,
            email VARCHAR(150) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL,
            rol VARCHAR(30) NOT NULL DEFAULT 'usuario',
            fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        self::safe($conexion, "ALTER TABLE usuarios ADD COLUMN rol VARCHAR(30) NOT NULL DEFAULT 'usuario'");

        // Admin de prueba. Se crea antes de las claves foráneas porque puede servir
        // como dueño de plantillas antiguas que hayan quedado sin usuario válido.
        self::asegurarAdmin($conexion);

        // =========================================================
        // 2. Tabla imagenes
        // =========================================================
        // Versión más normalizada: se dejan solo los campos que usa el sistema.
        // La imagen física no se guarda pesada en la base; se guarda su ruta.

        self::safe($conexion, "CREATE TABLE IF NOT EXISTS imagenes (
            id INT AUTO_INCREMENT PRIMARY KEY,
            clave VARCHAR(120) NOT NULL UNIQUE,
            nombre VARCHAR(180) NULL,
            tipo_mime VARCHAR(120) NULL,
            ruta_archivo VARCHAR(1000) NOT NULL,
            fecha_subida TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // Estas columnas son las que usa la versión ordenada del proyecto.
        // Si la tabla ya existía, se agregan solo si faltaban.
        foreach ([
            "ALTER TABLE imagenes ADD COLUMN clave VARCHAR(120) NULL",
            "ALTER TABLE imagenes ADD COLUMN nombre VARCHAR(180) NULL",
            "ALTER TABLE imagenes ADD COLUMN tipo_mime VARCHAR(120) NULL",
            "ALTER TABLE imagenes ADD COLUMN ruta_archivo VARCHAR(1000) NULL",
            "ALTER TABLE imagenes MODIFY ruta_archivo VARCHAR(1000) NULL",
            "ALTER TABLE imagenes ADD COLUMN fecha_subida TIMESTAMP DEFAULT CURRENT_TIMESTAMP",
            "ALTER TABLE imagenes ADD UNIQUE KEY clave_unica (clave)"
        ] as $sql) {
            self::safe($conexion, $sql);
        }

        // Si la base venía de una versión anterior, puede tener columnas viejas como
        // url, mime, contenido o datos. No se borran automáticamente para no perder datos,
        // pero copiamos lo útil a la columna nueva ruta_archivo/tipo_mime.
        self::migrarImagenesViejas($conexion);

        // =========================================================
        // 3. Tabla plantillas
        // =========================================================
        // Cada plantilla pertenece a un usuario y puede tener una imagen preview.

        self::safe($conexion, "CREATE TABLE IF NOT EXISTS plantillas (
            id INT AUTO_INCREMENT PRIMARY KEY,
            id_usuario INT NOT NULL,
            nombre VARCHAR(120) NOT NULL,
            categoria VARCHAR(60) NOT NULL,
            descripcion TEXT NOT NULL,
            id_imagen_preview INT NULL,
            carpeta VARCHAR(255) NULL,
            archivo_principal VARCHAR(255) NULL,
            fecha_subida TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        foreach ([
            "ALTER TABLE plantillas ADD COLUMN id_usuario INT NULL",
            "ALTER TABLE plantillas ADD COLUMN nombre VARCHAR(120) NULL",
            "ALTER TABLE plantillas ADD COLUMN categoria VARCHAR(60) NULL",
            "ALTER TABLE plantillas ADD COLUMN descripcion TEXT NULL",
            "ALTER TABLE plantillas ADD COLUMN id_imagen_preview INT NULL",
            "ALTER TABLE plantillas ADD COLUMN carpeta VARCHAR(255) NULL",
            "ALTER TABLE plantillas ADD COLUMN archivo_principal VARCHAR(255) NULL",
            "ALTER TABLE plantillas ADD COLUMN fecha_subida TIMESTAMP DEFAULT CURRENT_TIMESTAMP"
        ] as $sql) {
            self::safe($conexion, $sql);
        }

        // =========================================================
        // 4. Tabla archivos_plantilla
        // =========================================================
        // Guarda cada archivo real subido para una plantilla.

        self::safe($conexion, "CREATE TABLE IF NOT EXISTS archivos_plantilla (
            id INT AUTO_INCREMENT PRIMARY KEY,
            id_plantilla INT NOT NULL,
            nombre_original VARCHAR(180) NOT NULL,
            ruta_archivo VARCHAR(255) NOT NULL,
            extension VARCHAR(20) NOT NULL,
            fecha_subida TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        foreach ([
            "ALTER TABLE archivos_plantilla ADD COLUMN id_plantilla INT NULL",
            "ALTER TABLE archivos_plantilla ADD COLUMN nombre_original VARCHAR(180) NULL",
            "ALTER TABLE archivos_plantilla ADD COLUMN ruta_archivo VARCHAR(255) NULL",
            "ALTER TABLE archivos_plantilla ADD COLUMN extension VARCHAR(20) NULL",
            "ALTER TABLE archivos_plantilla ADD COLUMN fecha_subida TIMESTAMP DEFAULT CURRENT_TIMESTAMP"
        ] as $sql) {
            self::safe($conexion, $sql);
        }

        // =========================================================
        // 5. Limpieza mínima antes de crear claves foráneas
        // =========================================================
        // Una clave foránea no se puede crear si ya existen datos huérfanos.
        // Por eso se corrigen registros viejos antes de agregar las relaciones.

        self::limpiarDatosHuerfanos($conexion);

        // =========================================================
        // 6. Índices y claves foráneas
        // =========================================================
        // Acá sí quedan conectadas las tablas desde MySQL, no solo desde PHP.

        self::agregarRelaciones($conexion);
    }

    /**
     * Crea un usuario administrador inicial si todavía no existe.
     */
    private static function asegurarAdmin(mysqli $conexion): void
    {
        $emailAdmin = 'admin@getinweb.com';

        $check = $conexion->prepare('SELECT id FROM usuarios WHERE email = ?');
        $check->bind_param('s', $emailAdmin);
        $check->execute();
        $resultado = $check->get_result();

        if ($resultado->num_rows === 0) {
            $nombre = 'Administrador';
            $password = password_hash('Admin1234', PASSWORD_DEFAULT);
            $rol = 'admin';

            $insert = $conexion->prepare('INSERT INTO usuarios (nombre, email, password, rol) VALUES (?, ?, ?, ?)');
            $insert->bind_param('ssss', $nombre, $emailAdmin, $password, $rol);
            $insert->execute();
        }
    }

    /**
     * Copia datos útiles desde columnas antiguas de imagenes hacia las columnas nuevas.
     *
     * No borra columnas viejas automáticamente. Solo acomoda los datos para que el código
     * nuevo use ruta_archivo y tipo_mime.
     */
    private static function migrarImagenesViejas(mysqli $conexion): void
    {
        // Si existía url y ruta_archivo está vacía, copiamos url a ruta_archivo.
        self::safe($conexion, "UPDATE imagenes
            SET ruta_archivo = url
            WHERE (ruta_archivo IS NULL OR ruta_archivo = '')
            AND url IS NOT NULL
            AND url <> ''");

        // Si existía mime y tipo_mime está vacío, copiamos mime a tipo_mime.
        self::safe($conexion, "UPDATE imagenes
            SET tipo_mime = mime
            WHERE (tipo_mime IS NULL OR tipo_mime = '')
            AND mime IS NOT NULL
            AND mime <> ''");
    }

    /**
     * Corrige registros que impedirían crear claves foráneas.
     */
    private static function limpiarDatosHuerfanos(mysqli $conexion): void
    {
        // Si una plantilla quedó asociada a un usuario que ya no existe,
        // se asigna al administrador inicial.
        self::safe($conexion, "UPDATE plantillas p
            LEFT JOIN usuarios u ON p.id_usuario = u.id
            SET p.id_usuario = (SELECT id FROM usuarios WHERE email = 'admin@getinweb.com' LIMIT 1)
            WHERE u.id IS NULL");

        // Si una plantilla apunta a una imagen inexistente, se limpia esa referencia.
        self::safe($conexion, "UPDATE plantillas p
            LEFT JOIN imagenes i ON p.id_imagen_preview = i.id
            SET p.id_imagen_preview = NULL
            WHERE p.id_imagen_preview IS NOT NULL
            AND i.id IS NULL");

        // Si hay archivos que apuntan a plantillas inexistentes, se eliminan esos registros.
        // Esto borra solo el registro de base, no archivos físicos sueltos.
        self::safe($conexion, "DELETE a FROM archivos_plantilla a
            LEFT JOIN plantillas p ON a.id_plantilla = p.id
            WHERE p.id IS NULL");
    }

    /**
     * Agrega índices y claves foráneas entre tablas.
     */
    private static function agregarRelaciones(mysqli $conexion): void
    {
        // Índices necesarios para claves foráneas y búsquedas.
        foreach ([
            "ALTER TABLE plantillas ADD INDEX idx_plantillas_usuario (id_usuario)",
            "ALTER TABLE plantillas ADD INDEX idx_plantillas_imagen_preview (id_imagen_preview)",
            "ALTER TABLE archivos_plantilla ADD INDEX idx_archivos_plantilla (id_plantilla)"
        ] as $sql) {
            self::safe($conexion, $sql);
        }

        // Relación: una plantilla pertenece a un usuario.
        self::safe($conexion, "ALTER TABLE plantillas
            ADD CONSTRAINT fk_plantillas_usuarios
            FOREIGN KEY (id_usuario)
            REFERENCES usuarios(id)
            ON DELETE CASCADE
            ON UPDATE CASCADE");

        // Relación: una plantilla puede tener una imagen preview.
        self::safe($conexion, "ALTER TABLE plantillas
            ADD CONSTRAINT fk_plantillas_imagenes
            FOREIGN KEY (id_imagen_preview)
            REFERENCES imagenes(id)
            ON DELETE SET NULL
            ON UPDATE CASCADE");

        // Relación: cada archivo pertenece a una plantilla.
        self::safe($conexion, "ALTER TABLE archivos_plantilla
            ADD CONSTRAINT fk_archivos_plantilla_plantillas
            FOREIGN KEY (id_plantilla)
            REFERENCES plantillas(id)
            ON DELETE CASCADE
            ON UPDATE CASCADE");
    }
}
?>
