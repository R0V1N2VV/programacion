<?php
// VERSIÓN COMENTADA PARA ESTUDIO.

/*
    DAO de plantillas.

    Maneja las consultas SQL de la tabla plantillas.
    La página o el servicio no escriben el INSERT/SELECT directamente:
    se lo piden a esta clase.
*/

namespace App\DAO;

use mysqli;

class PlantillaDAO
{
    // Cada DAO recibe la conexión. No la crea, solamente la usa.
    public function __construct(private mysqli $conexion) {}

    /**
     * Busca plantillas para mostrarlas en explorador.php.
     */
    public function buscar(string $busqueda = '', string $categoria = 'todas'): array
    {
        $sql = 'SELECT plantillas.*, usuarios.nombre AS nombre_usuario
                FROM plantillas
                INNER JOIN usuarios ON plantillas.id_usuario = usuarios.id
                WHERE 1';

        $parametros = [];
        $tipos = '';

        if ($busqueda !== '') {
            $sql .= ' AND (plantillas.nombre LIKE ? OR plantillas.descripcion LIKE ?)';

            $textoBuscado = '%' . $busqueda . '%';
            $parametros[] = $textoBuscado;
            $parametros[] = $textoBuscado;
            $tipos .= 'ss';
        }

        if ($categoria !== 'todas') {
            $sql .= ' AND plantillas.categoria = ?';

            $parametros[] = $categoria;
            $tipos .= 's';
        }

        $sql .= ' ORDER BY plantillas.fecha_subida DESC';

        $stmt = $this->conexion->prepare($sql);

        if (!empty($parametros)) {
            $stmt->bind_param($tipos, ...$parametros);
        }

        $stmt->execute();

        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    /**
     * Busca una plantilla puntual junto con el nombre del usuario que la subió.
     */
    public function buscarPorIdConUsuario(int $id): ?array
    {
        $sql = 'SELECT plantillas.*, usuarios.nombre AS nombre_usuario
                FROM plantillas
                INNER JOIN usuarios ON plantillas.id_usuario = usuarios.id
                WHERE plantillas.id = ?';

        $stmt = $this->conexion->prepare($sql);
        $stmt->bind_param('i', $id);
        $stmt->execute();

        $resultado = $stmt->get_result();

        return $resultado->num_rows === 1 ? $resultado->fetch_assoc() : null;
    }

    /**
     * Crea el registro principal de una plantilla.
     *
     * Todavía no guarda la carpeta porque para crear la carpeta usamos el ID
     * que MySQL devuelve después del INSERT.
     */
    public function crear(
        int $usuarioId,
        string $nombre,
        string $categoria,
        string $descripcion,
        int $idImagenPreview
    ): int {
        $sql = 'INSERT INTO plantillas
                (id_usuario, nombre, categoria, descripcion, id_imagen_preview, carpeta, archivo_principal)
                VALUES (?, ?, ?, ?, ?, NULL, NULL)';

        $stmt = $this->conexion->prepare($sql);
        $stmt->bind_param('isssi', $usuarioId, $nombre, $categoria, $descripcion, $idImagenPreview);
        $stmt->execute();

        return $this->conexion->insert_id;
    }

    /**
     * Actualiza dónde quedaron guardados los archivos reales de la plantilla.
     */
    public function actualizarAlmacenamiento(int $id, string $carpeta, ?string $archivoPrincipal): void
    {
        $sql = 'UPDATE plantillas
                SET carpeta = ?, archivo_principal = ?
                WHERE id = ?';

        $stmt = $this->conexion->prepare($sql);
        $stmt->bind_param('ssi', $carpeta, $archivoPrincipal, $id);
        $stmt->execute();
    }

    public function borrar(int $id): void
    {
        $sql = 'DELETE FROM plantillas WHERE id = ?';
        $stmt = $this->conexion->prepare($sql);

        $stmt->bind_param('i', $id);
        $stmt->execute();
    }
}
