<?php
// VERSIÓN COMENTADA PARA ESTUDIO.

/*
    DAO de imágenes.

    Esta clase se encarga de guardar y buscar imágenes en la base de datos.
    La base no guarda la imagen pesada completa: guarda la ruta o URL donde está.
*/

namespace App\DAO;

use mysqli;

class ImagenDAO
{
    // Cada DAO recibe la conexión. No la crea, solamente la usa.
    public function __construct(private mysqli $conexion) {}

    public function buscarPorId(int $id): ?array
    {
        $sql = 'SELECT * FROM imagenes WHERE id = ?';
        $stmt = $this->conexion->prepare($sql);

        $stmt->bind_param('i', $id);
        $stmt->execute();

        $resultado = $stmt->get_result();

        return $resultado->num_rows === 1 ? $resultado->fetch_assoc() : null;
    }

    public function buscarPorClave(string $clave): ?array
    {
        $sql = 'SELECT * FROM imagenes WHERE clave = ?';
        $stmt = $this->conexion->prepare($sql);

        $stmt->bind_param('s', $clave);
        $stmt->execute();

        $resultado = $stmt->get_result();

        return $resultado->num_rows === 1 ? $resultado->fetch_assoc() : null;
    }

    /**
     * Guarda una imagen fija del sitio o actualiza su ruta si ya existía.
     *
     * Se usa para imágenes como inicio_wix, generador, plantilla_tienda, etc.
     */
    public function guardarOActualizarRuta(string $clave, string $ruta, string $nombre, string $mime): bool
    {
        $sql = 'INSERT INTO imagenes (clave, nombre, tipo_mime, ruta_archivo)
                VALUES (?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE
                    nombre = VALUES(nombre),
                    tipo_mime = VALUES(tipo_mime),
                    ruta_archivo = VALUES(ruta_archivo)';

        $stmt = $this->conexion->prepare($sql);
        $stmt->bind_param('ssss', $clave, $nombre, $mime, $ruta);

        return $stmt->execute();
    }

    /**
     * Inserta la imagen de vista previa de una plantilla.
     *
     * Devuelve el ID que generó MySQL para poder relacionarlo con plantillas.id_imagen_preview.
     */
    public function insertarPreview(string $clave, string $nombre, string $mime, string $ruta): int
    {
        $sql = 'INSERT INTO imagenes (clave, nombre, tipo_mime, ruta_archivo)
                VALUES (?, ?, ?, ?)';

        $stmt = $this->conexion->prepare($sql);
        $stmt->bind_param('ssss', $clave, $nombre, $mime, $ruta);
        $stmt->execute();

        return $this->conexion->insert_id;
    }

    public function borrarPorId(int $id): void
    {
        $sql = 'DELETE FROM imagenes WHERE id = ?';
        $stmt = $this->conexion->prepare($sql);

        $stmt->bind_param('i', $id);
        $stmt->execute();
    }
}
