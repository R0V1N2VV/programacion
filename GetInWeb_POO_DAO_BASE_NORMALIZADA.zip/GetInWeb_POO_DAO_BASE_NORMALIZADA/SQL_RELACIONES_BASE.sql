-- SQL de referencia para ver las relaciones agregadas en la base.
-- No hace falta ejecutarlo manualmente si usás el proyecto, porque PreparadorBaseDatos.php lo intenta hacer automáticamente.

ALTER TABLE plantillas
ADD INDEX idx_plantillas_usuario (id_usuario);

ALTER TABLE plantillas
ADD INDEX idx_plantillas_imagen_preview (id_imagen_preview);

ALTER TABLE archivos_plantilla
ADD INDEX idx_archivos_plantilla (id_plantilla);

ALTER TABLE plantillas
ADD CONSTRAINT fk_plantillas_usuarios
FOREIGN KEY (id_usuario)
REFERENCES usuarios(id)
ON DELETE CASCADE
ON UPDATE CASCADE;

ALTER TABLE plantillas
ADD CONSTRAINT fk_plantillas_imagenes
FOREIGN KEY (id_imagen_preview)
REFERENCES imagenes(id)
ON DELETE SET NULL
ON UPDATE CASCADE;

ALTER TABLE archivos_plantilla
ADD CONSTRAINT fk_archivos_plantilla_plantillas
FOREIGN KEY (id_plantilla)
REFERENCES plantillas(id)
ON DELETE CASCADE
ON UPDATE CASCADE;
