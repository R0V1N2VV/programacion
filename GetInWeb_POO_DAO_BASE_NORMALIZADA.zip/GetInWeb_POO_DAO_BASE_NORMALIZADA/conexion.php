<?php
// VERSIÓN COMENTADA PARA ESTUDIO.

/*
    Archivo de conexión general.
    Desde acá se carga el autoload, se abre la conexión a MySQL
    y se prepara la estructura mínima de la base si falta alguna tabla.
*/

require_once __DIR__ . '/app/Configuracion/Autoload.php';

use App\Configuracion\BaseDatos;
use App\Servicios\PreparadorBaseDatos;

// =========================================================
// Este archivo deja disponible la variable $conexion.
// También prepara la base de datos si faltan tablas o columnas.
// =========================================================

$conexion = BaseDatos::obtenerConexion();

PreparadorBaseDatos::preparar($conexion);
