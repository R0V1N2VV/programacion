<?php
// VERSIÓN COMENTADA PARA ESTUDIO.

/*
    Pantalla de inicio de sesión.
    Recibe email y contraseña, llama al servicio de autenticación
    y, si los datos son correctos, envía al usuario al explorador.
*/

require_once "conexion.php";

use App\Servicios\ServicioAutenticacion;

// =========================================================
// 1. Inicio de sesión y variables
// =========================================================

ServicioAutenticacion::iniciarSesionSiHaceFalta();

$error = '';

// =========================================================
// 2. Procesamiento del formulario
// =========================================================

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $auth = new ServicioAutenticacion($conexion);

    if ($auth->login($email, $password)) {
        header('Location: explorador.php');
        exit();
    }

    $error = 'El email o la contraseña son incorrectos.';
}

// =========================================================
// 3. Función auxiliar para imprimir HTML seguro
// =========================================================

function e($valor): string
{
    return htmlspecialchars((string) $valor, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Iniciar sesión - GetInWeb</title>

    <link rel="stylesheet" href="php_extra.css?v=<?php echo filemtime('php_extra.css'); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>

<header>
    <div class="header-contenido">
        <div class="marca">
            <h2 class="logotipo">GetInWeb</h2>
            <span>Web Generator</span>
        </div>

        <a href="index.php" class="btn-header">Volver al inicio</a>
    </div>
</header>

<main class="auth-main">
    <section class="auth-card">
        <div class="auth-titulo">
            <h1>Iniciar sesión</h1>
            <p>Ingresá a tu cuenta para explorar y subir plantillas.</p>
        </div>

        <?php if ($error !== ''): ?>
            <p class="mensaje-error"><?php echo e($error); ?></p>
        <?php endif; ?>

        <form method="POST" class="auth-form">
            <div class="campo-auth">
                <label>Email</label>
                <input type="email" name="email" placeholder="Ingresá tu email" required>
            </div>

            <div class="campo-auth">
                <label>Contraseña</label>
                <input type="password" name="password" placeholder="Ingresá tu contraseña" required>
            </div>

            <button type="submit" class="btn-auth">Ingresar</button>
        </form>

        <div class="auth-extra">
            <p>¿No tenés cuenta?</p>
            <a href="registro.php">Registrarse</a>
        </div>
    </section>
</main>

</body>
</html>
